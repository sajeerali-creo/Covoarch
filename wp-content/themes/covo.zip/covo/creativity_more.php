 <?php
/* Template Name: Creativity_More */
?>
<?php get_header(); ?>  

<body class="loading">
<!-- <div class="loading" id="load"></div> -->
<!-- header -->


<div class="inner-header">
  <div class="container">
    <div class="logo-sp"><i class="icon-logo"></i></div>
    <div class="back-bt-sp">
      <button class="back-bt"><a href="http://www.covoarch.com/home/">Back</a></button>
    </div>
  </div>
</div>


<!-- Activity -->
<section class="each creatives inner-creative">
  <div class="container">
    <div class="row">
      <div class="col l12 m12 s12">
        <div class="col l12 s12 m12">
          <ul id="tabs-swipe-demo" class="tabs">
            <li class="tab"><a class="active" href="#test-swipe-1">EXTERIORS</a></li>
            <li class="tab"><a href="#test-swipe-2">INTERIOR</a></li>
            <li class="tab"><a href="#test-swipe-3">COMMERCIAL</a></li>
            <li class="tab"><a href="#test-swipe-4">RENOVATIONS</a></li>
            <li class="tab border-right-0"><a href="#test-swipe-5">ON GOING</a></li>
          </ul>
        </div>
        <div class="col l12 m12 s12">
          <div id="test-swipe-1" class="full-box">
            <div>
              <div class="left-w">
               
               <?php
              query_posts('category_name=exterior' );
              while ( have_posts() ) : the_post();
              ?>
                <div class="col l4 m4 s12 work-box">
                  <a href="<?php the_permalink();?>">
                    <div class="over valign-wrapper">
                      <i class="valign zmdi zmdi-more"></i>
                    </div>
                  </a>
                  <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
                </div>
                 <?php
                    endwhile;
                 ?>
              </div>
              <div class="right-w">
                <h2>Interior</h2>
                <h1>Design</h1>
                <p>We recognise the importance of striking the balance between commercial demands and creative ambitions. Our unrivalled experience, profound grasp of commercial needs and creative agility, mean we reach inspired solutions for our clients, without compromise.</p>
              </div>

              <!-- button -->
             
            </div>
          </div>
          <div id="test-swipe-2" class="full-box">
            <div class="animatedParent">
              <div class="left-w">
               
               <?php
              query_posts('category_name=interior' );
              while ( have_posts() ) : the_post();
              ?>
                <div class="col l4 m4 s12 work-box">
                  <a href="<?php the_permalink();?>">
                    <div class="over valign-wrapper">
                      <i class="valign zmdi zmdi-more"></i>
                    </div>
                  </a>
                  <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
                </div>
                 <?php
                    endwhile;
                 ?>

             
              </div>
              <div class="right-w">
                <h2>Arch</h2>
                <h1>Design</h1>
                <p>We recognise the importance of striking the balance between commercial demands and creative ambitions. Our unrivalled experience, profound grasp of commercial needs and creative agility, mean we reach inspired solutions for our clients, without compromise.</p>
              </div>
              <!-- button -->
             
            </div>
          </div>
          <div id="test-swipe-3" class="full-box">
            <div class="animatedParent">
              <div class="left-w">
                
                 <?php
              query_posts('category_name=commercial' );
              while ( have_posts() ) : the_post();
              ?>
                <div class="col l4 m4 s12 work-box">
                  <a href="<?php the_permalink();?>">
                    <div class="over valign-wrapper">
                      <i class="valign zmdi zmdi-more"></i>
                    </div>
                  </a>
                  <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
                </div>
                 <?php
                    endwhile;
                 ?>
              
              </div>
              <div class="right-w">
                <h2>Material</h2>
                <h1>Design</h1>
                <p>We recognise the importance of striking the balance between commercial demands and creative ambitions. Our unrivalled experience, profound grasp of commercial needs and creative agility, mean we reach inspired solutions for our clients, without compromise.</p>
              </div>
              <!-- button -->
             
            </div>
          </div>
          <div id="test-swipe-4" class="full-box">
            <div class="animatedParent">
              <div class="left-w">
              
                 <?php
              query_posts('category_name=renovation' );
              while ( have_posts() ) : the_post();
              ?>
                <div class="col l4 m4 s12 work-box">
                  <a href="<?php the_permalink();?>">
                    <div class="over valign-wrapper">
                      <i class="valign zmdi zmdi-more"></i>
                    </div>
                  </a>
                  <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
                </div>
                 <?php
                    endwhile;
                 ?>
               </div>

              <div class="right-w">
                <h2>Exterior</h2>
                <h1>Design</h1>
                <p>We recognise the importance of striking the balance between commercial demands and creative ambitions. Our unrivalled experience, profound grasp of commercial needs and creative agility, mean we reach inspired solutions for our clients, without compromise.</p>
              </div>
              <!-- button -->
              
            </div>
          </div>
          <div id="test-swipe-5" class="full-box">
            <div class="animatedParent">
              <div class="left-w">
                
                <?php
              query_posts('category_name=ongoing' );
              while ( have_posts() ) : the_post();
              ?>
                <div class="col l4 m4 s12 work-box">
                  <a href="<?php the_permalink();?>">
                    <div class="over valign-wrapper">
                      <i class="valign zmdi zmdi-more"></i>
                    </div>
                  </a>
                  <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
                </div>
                 <?php
                    endwhile;
                 ?>
               
              </div>
              <div class="right-w">
                <h2>Exterior</h2>
                <h1>Design</h1>
                <p>We recognise the importance of striking the balance between commercial demands and creative ambitions. Our unrivalled experience, profound grasp of commercial needs and creative agility, mean we reach inspired solutions for our clients, without compromise.</p>
              </div>
              <!-- button -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
</section>

<?php get_footer(); ?>